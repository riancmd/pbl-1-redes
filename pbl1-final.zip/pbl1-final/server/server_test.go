package main

import (
	"encoding/json"
	"fmt"
	"net"
	"strconv"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// define o número de clientes bot que serão gerados
const numBots = 50

// struct para representar um bot cliente
type Bot struct {
	t           *testing.T
	id          int
	username    string
	password    string
	conn        net.Conn
	enc         *json.Encoder
	dec         *json.Decoder
	uid         string
	inBattle    bool
	cardsInHand int
}

// um mutex global para evitar que prints de testes concorrentes se misturem
var printMutex sync.Mutex

// a variável atômica para contar os bots que entraram na fila
var enqueuedBots int32

// a variável atômica para contar os bots que entraram em batalha
var inBattleBots int32

// a variável atômica para contar os pacotes que foram comprados
var packsBought int32

// a variável atômica para contar os jogos que terminaram
var finishedGames int32

// TestStressBot simula múltiplos bots interagindo com o servidor
func TestStressBot(t *testing.T) {
	// limpa as variáveis de contagem antes do teste
	atomic.StoreInt32(&enqueuedBots, 0)
	atomic.StoreInt32(&inBattleBots, 0)
	atomic.StoreInt32(&packsBought, 0)
	atomic.StoreInt32(&finishedGames, 0)

	// conecta cada bot ao servidor
	var bots []*Bot
	for i := 0; i < numBots; i++ {
		bot := &Bot{
			t:        t,
			id:       i,
			username: "bot_" + strconv.Itoa(i),
			password: "pass_" + strconv.Itoa(i),
		}
		conn, err := net.Dial("tcp", ":8080")
		if err != nil {
			t.Fatalf("falha ao conectar o bot %d: %v", i, err)
		}
		bot.conn = conn
		bot.enc = json.NewEncoder(conn)
		bot.dec = json.NewDecoder(conn)
		bots = append(bots, bot)
	}

	// um waitgroup para esperar que todos os bots terminem suas operações
	var wg sync.WaitGroup
	wg.Add(numBots)

	// começa os testes para cada bot em sua própria goroutine
	for _, bot := range bots {
		go bot.run(&wg)
	}

	// espera todos os bots terminarem
	wg.Wait()

	// verifica os resultados finais
	t.Run("Verifica o Status Final", func(t *testing.T) {
		printMutex.Lock()
		defer printMutex.Unlock()

		fmt.Printf("\n--- resumo do teste ---\n")
		fmt.Printf("bots enfileirados: %d/%d\n", atomic.LoadInt32(&enqueuedBots), numBots)
		fmt.Printf("bots em batalha: %d/%d\n", atomic.LoadInt32(&inBattleBots), numBots)
		fmt.Printf("pacotes comprados: %d\n", atomic.LoadInt32(&packsBought))
		fmt.Printf("jogos finalizados: %d\n", atomic.LoadInt32(&finishedGames))

		// a sanidade dos bots que entraram em batalha deve ser 0
		if atomic.LoadInt32(&inBattleBots) != numBots {
			t.Errorf("nem todos os bots entraram em batalha. esperava %d, obteve %d", numBots, atomic.LoadInt32(&inBattleBots))
		}

		if atomic.LoadInt32(&finishedGames) != numBots/2 {
			t.Errorf("número de jogos finalizados incorreto. esperava %d, obteve %d", numBots/2, atomic.LoadInt32(&finishedGames))
		}
	})

	// fecha todas as conexões
	for _, bot := range bots {
		bot.conn.Close()
	}
}

// run contém a lógica de teste para um único bot
func (b *Bot) run(wg *sync.WaitGroup) {
	defer wg.Done()

	// 1. registrar e fazer login
	b.testRegister()
	if b.uid == "" {
		return // se o registro falhar, para o teste
	}

	// 2. comprar pacotes de cartas
	b.testBuyPack()

	// 3. entrar na fila de batalha
	b.testEnqueue()

	// se o bot entrou em batalha, começa a jogar
	if b.inBattle {
		b.testPlayGame()
	}
}

// testa o registro e login
func (b *Bot) testRegister() {
	b.t.Helper()
	reqData, _ := json.Marshal(map[string]string{
		"username": b.username,
		"password": b.password,
	})
	req := Message{Request: register, Data: reqData}

	err := b.enc.Encode(req)
	if err != nil {
		b.t.Errorf("bot %d: falha ao enviar registro: %v", b.id, err)
		return
	}

	// espera a resposta de registro
	var res Message
	b.dec.Decode(&res)
	if res.Request != registered {
		b.t.Errorf("bot %d: falha no registro. resposta inesperada: %s", b.id, res.Request)
		return
	}

	var payload PlayerResponse
	json.Unmarshal(res.Data, &payload)
	b.uid = payload.UID

	printMutex.Lock()
	fmt.Printf("✅ bot %d (%s) registrado com sucesso. uid: %s\n", b.id, b.username, b.uid)
	printMutex.Unlock()

	// consome as 4 mensagens de "packbought"
	for i := 0; i < 4; i++ {
		var packRes Message
		b.dec.Decode(&packRes)
		if packRes.Request != packbought {
			// A lógica era errada aqui, se cair nesse if, o teste realmente falha
			b.t.Errorf("bot %d: falha ao receber pacote gratuito (esperava %s, obteve %s)", b.id, packbought, packRes.Request)
		}
	}
}

// testa a compra de um pacote de cartas
func (b *Bot) testBuyPack() {
	b.t.Helper()
	// pequeno delay para evitar que a requisição de compra se misture com as
	// respostas de "packbought" do registro
	time.Sleep(100 * time.Millisecond)

	req := Message{
		Request: buypack,
		UID:     b.uid,
		Data:    json.RawMessage(`{"UID":"` + b.uid + `"}`),
	}

	err := b.enc.Encode(req)
	if err != nil {
		b.t.Errorf("bot %d: falha ao enviar requisição de compra: %v", b.id, err)
		return
	}

	var res Message
	b.dec.Decode(&res)
	if res.Request != packbought {
		b.t.Errorf("bot %d: falha ao comprar pacote. resposta inesperada: %s", b.id, res.Request)
		return
	}

	atomic.AddInt32(&packsBought, 1)

	printMutex.Lock()
	fmt.Printf("💰 bot %d comprou um novo pacote\n", b.id)
	printMutex.Unlock()
}

// testa a entrada na fila
func (b *Bot) testEnqueue() {
	b.t.Helper()
	req := Message{
		Request: battle,
		UID:     b.uid,
		Data:    json.RawMessage(`{"UID":"` + b.uid + `"}`),
	}

	err := b.enc.Encode(req)
	if err != nil {
		b.t.Errorf("bot %d: falha ao enviar requisição de batalha: %v", b.id, err)
		return
	}

	atomic.AddInt32(&enqueuedBots, 1)

	// espera a resposta de "enqueued" ou "gamestart"
	var res Message
	b.dec.Decode(&res)

	if res.Request == enqueued {
		printMutex.Lock()
		fmt.Printf("⏳ bot %d entrou na fila. esperando por um oponente...\n", b.id)
		printMutex.Unlock()
		b.dec.Decode(&res)
	}

	if res.Request == gamestart {
		atomic.AddInt32(&inBattleBots, 1)
		b.inBattle = true
		printMutex.Lock()
		fmt.Printf("⚔️ bot %d entrou em batalha!\n", b.id)
		printMutex.Unlock()

		// processa os dados iniciais do jogo
		var payload struct {
			Hand []Card
		}
		json.Unmarshal(res.Data, &payload)
		b.cardsInHand = len(payload.Hand)
	} else {
		b.t.Errorf("bot %d: falha ao entrar em batalha. resposta inesperada: %s", b.id, res.Request)
	}
}

// testa a jogabilidade, jogando cartas até o jogo acabar
func (b *Bot) testPlayGame() {
	b.t.Helper()
	for {
		var res Message
		err := b.dec.Decode(&res)
		if err != nil {
			b.t.Errorf("bot %d: erro ao ler mensagem da partida: %v", b.id, err)
			return
		}

		switch res.Request {
		case newturn:
			var payload struct {
				Turn string
			}
			json.Unmarshal(res.Data, &payload)
			if payload.Turn == b.uid {
				// é o nosso turno, então joga uma carta
				if b.cardsInHand > 0 {
					b.playCard()
				} else {
					// se não houver mais cartas, desiste
					b.giveUp()
				}
			}
		case newvictory, newloss, newtie:
			// o jogo terminou
			atomic.AddInt32(&finishedGames, 1)
			printMutex.Lock()
			fmt.Printf("🏁 bot %d terminou a partida com o resultado: %s\n", b.id, res.Request)
			printMutex.Unlock()
			return // sai da goroutine de jogo
		case notify:
			// ignora mensagens de notificação
		case updateinfo:
			// ignora mensagens de atualização
		default:
			b.t.Logf("bot %d: mensagem desconhecida recebida: %s", b.id, res.Request)
		}
	}
}

// simula o bot jogando uma carta (a primeira da mão)
func (b *Bot) playCard() {
	b.t.Helper()
	// uma requisição genérica para usar uma carta, o server que valida se a carta existe
	cardReq := struct {
		Card Card `json:"card"`
	}{
		Card: Card{
			CID: "card_placeholder",
		},
	}
	reqData, _ := json.Marshal(cardReq)
	req := Message{
		Request: usecard,
		UID:     b.uid,
		Data:    reqData,
	}

	b.enc.Encode(req)

	// diminui o contador de cartas na mão, já que o bot jogou uma
	b.cardsInHand--

	printMutex.Lock()
	fmt.Printf("🤖 bot %d jogou uma carta. cartas restantes: %d\n", b.id, b.cardsInHand)
	printMutex.Unlock()
}

// simula o bot desistindo da partida
func (b *Bot) giveUp() {
	b.t.Helper()
	req := Message{
		Request: giveup,
		UID:     b.uid,
		Data:    json.RawMessage(`{}`),
	}
	b.enc.Encode(req)

	printMutex.Lock()
	fmt.Printf("🏳️ bot %d desistiu da partida\n", b.id)
	printMutex.Unlock()
}
